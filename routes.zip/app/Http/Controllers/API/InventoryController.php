<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Inventory;
use Illuminate\Support\Facades\Auth;

class InventoryController extends Controller
{
    public function index(Request $request){
        // $items=Inventory::all();
        $user_id= Auth::id();
        $items=Inventory::with('contains')->get();
        return response()->json([
            'text' => "inventory success",
            'items' => $items,
      
        ]);
    }
    public function store(Request $request){
        
        $inventory= new Inventory;
        $user_id = Auth::id();
        $inventory->user_id= $user_id;
        $inventory->product= $request->input('product');
        $inventory->amount=$request->input('amount');

        $inventory->save();

        

        return response()->json([
            'text' => "testing success",
          
            'user' =>$user_id,
            'amount' => $request->input('amount'),
            'product' => $request->input(),
            'items' => $items,
      
        ]);
    }
}
