import {Link, React, $,
    useEffect, useState,
} from "../../index";
import '../../../../public/css/party_tasks.css';

const TasksTab = () => {

    return( //will change class names
        <section className="container party-section">
            <div className="party-content" >
                <h1>TASKS LANDING PAGE</h1>
            </div>
        </section>
    )
}

export default TasksTab;
